#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

Status decode_open_stego_file(DecodeInfo *decInfo) // calling fn to open stego file
{
    // Stego Image file
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status decode_open_output_file(DecodeInfo *decInfo) // calling fn to open output files
{
    // Output file
    decInfo->fptr_output = fopen(decInfo->output_fname, "w");
    // Do Error handling
    if (decInfo->fptr_output == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo) // validates inputs
{
    // stego image file
    if (strstr(argv[2], ".bmp")) // check argv[2] has .bmp or not
    {
        // update into structure
        decInfo->stego_image_fname = argv[2]; // decInfo->stego_image_fname = argv[2];
    }
    else
    {
        // return e_failure
        return e_failure;
    }

    // output file
    if (argv[3] != NULL) // check input for output is given or not
    {
        // update into structure
        strcpy(decInfo->output_fname, strtok(argv[3], ".")); // decInfo->output_fname = argv[3] name
    }
    else
    {
        // default name
        strcpy(decInfo->output_fname, "output");
    }

    return e_success;
}

Status do_decoding(DecodeInfo *decInfo) // performs encoding
{
    if (decode_open_stego_file(decInfo) == e_failure) // calling fn to open stego file
    {
        printf("Stego File opening failed\n");
        return e_failure;
    }

    if (skip_bmp_header(decInfo->fptr_stego_image) == e_failure) // skips cpoying the bmp file header
    {
        printf("Skip bmp header failed\n");
        return e_failure;
    }

    if (decode_magic_string(decInfo) == e_failure) // decoding magic string
    {
        printf("Decoding magic string failed\n");
        return e_failure;
    }

    char magic_string[3];
    printf("Enter the magic string : "); // read magic string from user
    scanf("%s", magic_string);

    if (compare_magic_string(magic_string, decInfo) == e_failure) // compare magic string from user and decoded magic string
    {
        printf("Invalid magic string\n");
        return e_failure;
    }

    if (decode_output_file_extn_size(decInfo) == e_failure) // decodes file extension size
    {
        printf("Decoding file extension size failed\n");
        return e_failure;
    }

    if (decode_output_file_extn(decInfo) == e_failure) // decodes file extension
    {
        printf("Decoding file extension failed\n");
        return e_failure;
    }

    strcat(decInfo->output_fname, decInfo->secret_file_extn); // merges output file name and extension

    if (decode_open_output_file(decInfo) == e_failure) // calling fn to open stego file
    {
        printf("Output File opening failed\n");
        return e_failure;
    }

    if (decode_output_file_size(decInfo) == e_failure) // decodes file size
    {
        printf("Decoding file size failed\n");
        return e_failure;
    }

    if (decode_output_file_data(decInfo) == e_failure) // decodes file data
    {
        printf("Decoding file failed\n");
        return e_failure;
    }

    /* Close all opened files */
    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_output);

    return e_success;
}

Status skip_bmp_header(FILE *fptr_src_image) // skips cpoying the bmp file header
{
    fseek(fptr_src_image, 54, SEEK_SET); // move the fptr of stego file to 54 offset

    return e_success;
}

Status decode_magic_string(DecodeInfo *decInfo) // to decode magic string
{
    char image_buffer[8];
    int i;
    for (i = 0; i < 2; i++)
    {
        char ch = 0;
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image); // reading 8 bytes from stego file
        decode_lsb_to_byte(&ch, image_buffer);                // fn for decoding magic string
        decInfo->m_string[i] = ch;                            // storing characets in structure var
    }
    decInfo->m_string[i] = '\0';

    return e_success;
}

Status decode_lsb_to_byte(char *data, char *image_buffer) // decode lsb to byte logic
{
    // to decode 8 bits from 8 bytes
    for (int i = 0; i < 8; i++)
    {
        char ret = ((image_buffer[i] & 1) << (7 - i));
        // getting one msb bit from each byte of image_buffer
        // storing (modifing at address of data) at data
        *data = *data | ret;
    }

    return e_success;
}

Status compare_magic_string(char *user_m_string, DecodeInfo *decInfo) // compare magic string from user and decoded magic string
{
    if ((strcmp(decInfo->m_string, user_m_string) == 0))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }

    return e_success;
}

Status decode_output_file_extn_size(DecodeInfo *decInfo) // decodes output file extension size
{
    char image_buffer[32];
    int size = 0;

    fread(image_buffer, 32, 1, decInfo->fptr_stego_image); // reading 32 bytes from stego file
    decode_lsb_to_int(&size, image_buffer);                // fn for decoding file extension size
    decInfo->extn_size = size;                             // storing size of extension into structure var

    return e_success;
}

Status decode_lsb_to_int(int *size, char *image_buffer) // decode lsb to int logic
{
    char ret;
    // to decode 32 bits from 32 bytes
    for (int i = 0; i < 32; i++)
    {
        ret = ((image_buffer[i] & 1) << (31 - i));
        // getting one msb bit from each byte of image_buffer
        // storing (modifing at address of size) at size
        *size = *size | ret;
    }

    return e_success;
}

Status decode_output_file_extn(DecodeInfo *decInfo) // decodes output file extension size
{
    char image_buffer[8];
    int i;

    for (i = 0; i < decInfo->extn_size; i++)
    {
        char ch = 0;
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image); // reading 8 bytes from stego file
        decode_lsb_to_byte(&ch, image_buffer);                // fn for decoding file extension
        decInfo->secret_file_extn[i] = ch;                    // storing file extension into structure var
    }
    decInfo->secret_file_extn[i] = '\0';

    return e_success;
}

Status decode_output_file_size(DecodeInfo *decInfo) // decodes output file size
{
    char image_buffer[32];
    int size = 0;

    fread(image_buffer, 32, 1, decInfo->fptr_stego_image); // reading 32 bytes from stego file
    decode_lsb_to_int(&size, image_buffer);                // fn for decoding file size
    decInfo->file_size = size;                             // storing file size into structure var

    return e_success;
}

Status decode_output_file_data(DecodeInfo *decInfo)
{
    char image_buffer[8];
    int i;

    for (i = 0; i < decInfo->file_size; i++)
    {
        char ch = 0;
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image); // reading 8 bytes from stego file
        decode_lsb_to_byte(&ch, image_buffer);                // fn for decoding file data
        fwrite(&ch, 1, 1, decInfo->fptr_output);              // writing 1byte of char into output file
    }

    return e_success;
}
