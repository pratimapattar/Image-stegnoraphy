#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

/*
 * Structure to store information required for
 * decoding stego image to text file
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 5

typedef struct _DecodeInfo
{
    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;
    char m_string[3];
    uint extn_size;
    char secret_file_extn[5];
    uint file_size;

    /* Output File Info */
    char output_fname[50];
    FILE *fptr_output;

} DecodeInfo;

/* Deoding function prototype */

/* Check operation type */
// OperationType check_operation_type(char *argv[]);

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p files */
Status decode_open_stego_file(DecodeInfo *decInfo);

/* Get File pointers for o/p files */
Status decode_open_output_file(DecodeInfo *decInfo);

/* check capacity */
// Status check_capacity(DecodeInfo *decInfo);

/* Get image size */
// uint get_image_size_for_bmp(FILE *fptr_image);

/* Get file size */
// uint get_file_size(FILE *fptr);

/* Copy bmp image header */
Status skip_bmp_header(FILE *fptr_src_image);

/* Decode Magic String */
Status decode_magic_string(DecodeInfo *decInfo);

/* Compare magic string from user with decoded magic string */
Status compare_magic_string(char *user_m_string, DecodeInfo *DecodeInfo);

/* Decode output file extenstion size */
Status decode_output_file_extn_size(DecodeInfo *decInfo);

/* Decode output file extenstion */
Status decode_output_file_extn(DecodeInfo *decInfo);

/* Decode output file size */
Status decode_output_file_size(DecodeInfo *decInfo);

/* Decode output file data*/
Status decode_output_file_data(DecodeInfo *decInfo);

/* Decode function, which does the real Decoding */
// Status decode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Decode a byte into LSB of image data array */
Status decode_lsb_to_byte(char *data, char *image_buffer);

/* Decode a int into LSB of image data array */
Status decode_lsb_to_int(int *size, char *image_buffer);

/* Copy remaining image bytes from src to stego image after decoding */
// Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif
