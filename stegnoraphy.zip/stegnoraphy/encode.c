#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_encode_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // source image file
    if (strstr(argv[2], ".bmp")) // check argv[2] has .bmp or not
    {
        // update into structure
        encInfo->src_image_fname = argv[2]; // encInfo->src_image_frame = argv[2];
    }
    else
    {
        // return e_failure
        return e_failure;
    }

    // secret file
    if (strstr(argv[3], ".txt")) // check argv[3] has .txt or not
    {
        // update into structure
        encInfo->secret_fname = argv[3]; // encInfo->secret_fname = argv[3];

        // get and store extn of secret file into   encInfo->extn_secret_file for decoding
        char *ptr = strrchr(argv[3], '.');
        if (ptr == NULL)
        {
            return e_failure;
        }

        strcpy(encInfo->extn_secret_file, ptr);
    }
    else
    {
        // return e_failure
        return e_failure;
    }

    // stego image file
    if (argv[4] == NULL)
    {
        // default name
        // update stego_image_fname = "stego.bmp";
        encInfo->stego_image_fname = "stego.bmp";
    }
    else
    {
        char *ptr = strrchr(argv[4], '.');
        if (ptr && strcmp(ptr, ".bmp") == 0) // check argv[4] has .bmp or not
        {
            // update into structure
            encInfo->stego_image_fname = argv[4]; // stego_image_fname = argv[4];
        }
        else
        {
            return e_failure;
        }
    }

    return e_success; // return e_success
}

Status do_encoding(EncodeInfo *encInfo) // performs encoding
{
    if (open_encode_files(encInfo) == e_failure) // calling fn to open files
    {
        printf("File opening failed\n");
        return e_failure;
    }

    if (check_capacity(encInfo) == e_failure) // check capacity of src_image
    {
        printf("Image capacity is not sufficient\n");
        return e_failure;
    }

    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure) // copys 54 from src to stego file
    {
        printf("Failed copy bmp header\n");
        return e_failure;
    }

    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure) // to encode magic string
    {
        printf("Failed encode magic string\n");
        return e_failure;
    }

    if (encode_secret_file_extn_size(encInfo) == e_failure) // to encode secrete file extn size (4 byte(int))
    {
        printf("Failed to encode extension size\n");
        return e_failure;
    }

    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_failure) // to encode secrete_file extn
    {
        printf("Failed to encode extension \n");
        return e_failure;
    }

    if (encode_secret_file_size(encInfo) == e_failure) // to encode secret_file_size
    {
        printf("Failed to encode file size \n");
        return e_failure;
    }

    if (encode_secret_file_data(encInfo) == e_failure) // to encode secrete file data
    {
        printf("Failed to encode file data\n");
        return e_failure;
    }

    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure) // copy remaining file data
    {
        printf("Failed to copy remaining data\n");
        return e_failure;
    }

    /* Close all opened files */
    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_stego_image);

    return e_success;
}

Status check_capacity(EncodeInfo *encInfo) // check capacity of src_image
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image); // size of src file
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);           // size of secrete file
    // strlen(MAGIC_STRING) - sizeof_magic_string = 2,  sizeof_type_of_extn = 4(int), strlen(encInfo->extn_secret_file) - sizeof_extn = 4, sizeof_type_of_file = 4(int) , encInfo->size_secret_file - sizeof_file = 4
    if (encInfo->image_capacity > (strlen(MAGIC_STRING) + sizeof(int) + strlen(encInfo->extn_secret_file) + sizeof(int) + encInfo->size_secret_file) * 8)
    {
        return e_success;
    }

    return e_failure;
}

Status get_file_size(FILE *fptr) // finds size of secret file
{
    fseek(fptr, 0, SEEK_END); // fseek moves file ptr to end of file
    long size = ftell(fptr);  // gives offset of fptr
    rewind(fptr);             // rewinding ptr back to initial position

    return size;
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image) // copys 54 bytes from src_file to stego_file
{
    char buffer[54];

    rewind(fptr_src_image); // rewinding src_file ptr to initial position

    fread(buffer, 54, 1, fptr_src_image);   // read from src_file 54 bytes from buffer
    fwrite(buffer, 54, 1, fptr_dest_image); // write from src_file 54 bytes from buffer

    return e_success;
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo) // encodes magic string
{
    char image_buffer[8];

    int magic_string_len = strlen(MAGIC_STRING); // find sizeof magic string
    // call fn to encode magic_string for magic_string_len timezz
    for (int i = 0; i < magic_string_len; i++)
    {
        fread(image_buffer, 8, 1, encInfo->fptr_src_image); // reading 8 bytes from srcfile to buffer
        // call fn to encode each byte of magic string into 8 bytes image buffer
        encode_byte_to_lsb(magic_string[i], image_buffer);
        fwrite(image_buffer, 8, 1, encInfo->fptr_stego_image); // writing 8 bytes into stego_file from buffer
    }

    return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer) // encode byte to lsb logic
{
    for (int i = 0; i < 8; i++) // runs loop 8 times bcz to encode 8 bits
    {
        image_buffer[i] = image_buffer[i] & 0xFE; // clear bit from lsb of image buffer
        char ret = (data >> (7 - i)) & 1;         // get msb bit of data shift is to lsb side
        image_buffer[i] = image_buffer[i] | ret;  // set the getted bit of data to lsb of image_buffer
    }

    return e_success;
}

Status encode_secret_file_extn_size(EncodeInfo *encInfo) // encode secrete file extn size (4 byte(int))
{
    char image_buffer[32];

    int extn_size = strlen(encInfo->extn_secret_file);      // get extn size from extn_secret_file using strlen
    fread(image_buffer, 32, 1, encInfo->fptr_src_image);    // get 32 bytes from src_file to encode size (for 4 bytes - 4x8 = 32 bytes) using fread
    encode_int_to_lsb(extn_size, image_buffer);             // call fn to encode size of extn size into 32 bytes image buffer
    fwrite(image_buffer, 32, 1, encInfo->fptr_stego_image); // writing encoded size into stego_file using fwrite

    return e_success;
}

Status encode_int_to_lsb(int size, char *image_buffer) // encode int to lsb logic
{
    for (int i = 0; i < 32; i++) // run loop for 32 time to encode 32 bits of size
    {
        image_buffer[i] = image_buffer[i] & 0xFE; // clear bit from lsb of each byte of imge_buffer
        int ret = (size >> (31 - i)) & 1;         // get the bit from msb of size and shift it to (32-i) time to lsb
        image_buffer[i] = image_buffer[i] | ret;  // set the getted bit of data to lsb of image_buffer
    }

    return e_success;
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo) // encodes secret file extn
{
    char image_buffer[8];
    // call fn to encode secret_file_extn for extn_size timezz
    for (int i = 0; file_extn[i] != '\0'; i++)
    {
        fread(image_buffer, 8, 1, encInfo->fptr_src_image); // reading 8 bytes from src_file to buffer
        // call fn to encode each byte of secret_file_extn into 8 bytes image buffer
        encode_byte_to_lsb(encInfo->extn_secret_file[i], image_buffer);
        fwrite(image_buffer, 8, 1, encInfo->fptr_stego_image); // writing 8 bytes into stego_file from buffer
    }

    return e_success;
}

Status encode_secret_file_size(EncodeInfo *encInfo) // encodes secret file size(4 bytes(int))
{
    char image_buffer[32];

    fread(image_buffer, 32, 1, encInfo->fptr_src_image); // get 32 bytes from src_file to encode size (for 4 bytes - 4x8 = 32 bytes) using fread
    // file_size = encInfo->size_secret_file; //get file size from size_secret_file using strlen
    encode_int_to_lsb(encInfo->size_secret_file, image_buffer); // call fn to encode size of file size into 32 bytes image buffer
    fwrite(image_buffer, 32, 1, encInfo->fptr_stego_image);     // writing encoded size into stego_file using fwrite

    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo) // to encode secrete file data
{
    char image_buffer[8];
    char ch;

    while (fread(&ch, 1, 1, encInfo->fptr_secret)) // get 1 byte from secret file in encInfo->secret_data array times need to run loop
    {
        fread(image_buffer, 8, 1, encInfo->fptr_src_image);    // get 8 bytes from src file store in image_buffer
        encode_byte_to_lsb(ch, image_buffer);                  // call byte_to_lsb
        fwrite(image_buffer, 8, 1, encInfo->fptr_stego_image); // write encoded 8 bytes in stego file
    }

    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest) // copy remaining file data
{
    char ch;

    while (fread(&ch, 1, 1, fptr_src)) // get 1 byte from src file
    {
        fwrite(&ch, 1, 1, fptr_dest); // write 1 byte into stego file
    }

    return e_success;
}
