#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char *argv[]) // main collect arguments from CLA
{

    EncodeInfo encInfo;
    DecodeInfo decInfo;

    if (argc < 2)
    {
        printf("Usage : ./a.out -e/-d input_file.bmp input_file.txt \n");
        return 0;
    }

    int ret = check_operation_type(argv); // calling fn to check opearation

    if (ret == e_encode) // checks ret is encode is not
    {
        if (argc == 4 || argc == 5)
        {
            // encoding
            if (read_and_validate_encode_args(argv, &encInfo) == e_failure) // validates arguments
            {
                printf("Invalid Arguments\n");
                return 0;
            }

            if (do_encoding(&encInfo) == e_failure) // performs encoding
            {
                printf("Encoding Failed\n");
                return 0;
            }

            printf("Encoding Succefully\n");
        }
        else
        {
            printf("Usage : ./a.out -e input_file.bmp input_file.txt \n");
            return 0;
        }
    }
    else if (ret == e_decode) // checks ret is decode is not
    {
        if (argc == 3 || argc == 4)
        {
            // decoding
            if (read_and_validate_decode_args(argv, &decInfo) == e_failure) // validates arguments
            {
                printf("Invalid Arguments\n");
                return 0;
            }

            if (do_decoding(&decInfo) == e_failure) // performs encoding
            {
                printf("Decoding Failed\n");
                return 0;
            }

            printf("Decoding Succefully\n");
        }
        else
        {
            printf("Usage : ./a.out -d input_file.bmp\n");
            return 0;
        }
    }
    else
    {
        printf("Invalid operation\n");
    }

    return 0;
}

OperationType check_operation_type(char *argv[]) // fn to check operation type
{
    if (strcmp(argv[1], "-e") == 0) // if argv[1] is -e then encoding
    {
        // printf("Encoding operation\n");  //unwanted
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0) // if argv[1] is -d then encoding
    {
        // printf("Decoding operation\n");  //unwanted
        return e_decode;
    }
    else
    {
        return e_unsupported; // for unsupported operation
    }
}
